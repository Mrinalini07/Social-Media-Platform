document.getElementById('uploadAvatarForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('avatar', document.getElementById('avatar').files[0]);
  
    const response = await fetch('/upload/avatar', {
      method: 'POST',
      body: formData,
    });
  
    const data = await response.json();
    if (data.success) {
      alert('Avatar uploaded successfully!');
      // Update avatar display
      document.getElementById('userAvatar').src = data.avatarUrl;
    }
  });
  
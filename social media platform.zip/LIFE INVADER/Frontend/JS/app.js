require('dotenv').config();
document.addEventListener('DOMContentLoaded', () => {
    const likeButtons = document.querySelectorAll('.like-button');
  
    likeButtons.forEach(button => {
      button.addEventListener('click', () => {
        const likeCount = button.nextElementSibling;
        let count = parseInt(likeCount.textContent);
        likeCount.textContent = `${++count} likes`;
      });
    });
  });
  // Spinner logic
const spinner = document.getElementById('spinner');

// Function to show the spinner
function showSpinner() {
  if (spinner) spinner.style.display = 'block';
}

// Function to hide the spinner
function hideSpinner() {
  if (spinner) spinner.style.display = 'none';
}

// Fetch data example
async function fetchData() {
  try {
    showSpinner();
    const response = await fetch('/api/posts'); // Example API call
    const data = await response.json();
    console.log(data); // Handle the fetched data
  } catch (error) {
    console.error('Error fetching data:', error);
  } finally {
    hideSpinner();
  }
}

// Call fetchData for testing
fetchData();
  
async function sendMessage(message) {
  try {
      const response = await fetch('http://localhost:5000/sendMessage', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
          },
          body: JSON.stringify({ message }),
      });

      const data = await response.json();
      if (data.success) {
          console.log('Message sent successfully');
      } else {
          console.log('Error sending message');
      }
  } catch (error) {
      console.log('Error:', error);
  }
}

const postForm = document.getElementById('postForm');
const postsContainer = document.getElementById('posts');
const formData = new FormData();

formData.append('content', content);
if (image) formData.append('image', image);

fetch('/api/posts', {
    method: 'POST',
    body: formData,
})
    .then((response) => response.json())
    .then((data) => {
        if (response.ok) {
            console.log('Post created:', data);
        } else {
            console.error('Error creating post:', data.message);
        }
    })
    .catch((error) => console.error('Error:', error));

// Handle post submission
postForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const content = document.getElementById('content').value;
    const image = document.getElementById('image').files[0];

    const formData = new FormData();
    formData.append('content', content);
    if (image) formData.append('image', image);

    try {
        const res = await fetch('/api/posts', {
            method: 'POST',
            body: formData,
        });
        const data = await res.json();
        if (res.ok) {
            alert('Post created!');
            fetchPosts();
        } else {
            alert(data.message || 'Error creating post');
        }
    } catch (error) {
        console.error('Error creating post:', error);
    }
});

// Fetch and display posts
async function fetchPosts() {
    try {
        const res = await fetch('/api/posts');
        const posts = await res.json();
        postsContainer.innerHTML = '';
        posts.forEach((post) => {
            const postElement = document.createElement('div');
            postElement.innerHTML = `
                <p><strong>${post.user.username}</strong></p>
                <p>${post.content}</p>
                ${post.image ? `<img src="${post.image}" alt="Post image">` : ''}
                <small>${new Date(post.createdAt).toLocaleString()}</small>
            `;
            postsContainer.appendChild(postElement);
        });
    } catch (error) {
        console.error('Error fetching posts:', error);
    }
}

// Initial fetch
fetchPosts();

async function sendMessage(message) {
    try {
        const response = await fetch('http://localhost:5000/sendMessage', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message }),
        });

        const data = await response.json();
        if (data.success) {
            console.log('Message sent successfully');
        } else {
            console.log('Error sending message');
        }
    } catch (error) {
        console.log('Error:', error);
    }
}
document.getElementById('uploadPostForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('postImage', document.getElementById('postImage').files[0]);
  
    const response = await fetch('/upload/post-image', {
      method: 'POST',
      body: formData,
    });
  
    const data = await response.json();
    if (data.success) {
      alert('Post image uploaded successfully!');
      // Optionally refresh posts
    }
  });
  
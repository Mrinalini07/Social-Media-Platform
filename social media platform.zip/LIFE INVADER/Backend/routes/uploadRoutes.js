const express = require('express');
const { uploadAvatar, uploadPostImage } = require('./uploadConfig');
const router = express.Router();

// Upload Avatar
router.post('/upload/avatar', uploadAvatar.single('avatar'), (req, res) => {
  res.json({ success: true, avatarUrl: `/uploads/avatars/${req.file.filename}` });
});

// Upload Post Image
router.post('/upload/post-image', uploadPostImage.single('postImage'), (req, res) => {
  res.json({ success: true, imageUrl: `/uploads/posts/${req.file.filename}` });
});

module.exports = router;

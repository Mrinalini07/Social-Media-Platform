const express = require('express');
const User = require('../models/User');
const router = express.Router();

// Get user profile by username
router.get('/:username', async (req, res) => {
    try {
      const user = await User.findOne({ username: req.params.username }).select('-password');
      if (!user) return res.status(404).json({ message: 'User not found' });
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: 'Server Error' });
    }
  });
  
// Update user profile (bio, profile picture)
router.put('/:username', async (req, res) => {
  const { bio, profilePicture } = req.body;
  try {
    const user = await User.findOneAndUpdate(
      { username: req.params.username },
      { $set: { bio, profilePicture } },
      { new: true }
    ).select('-password');
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
});

// Follow or unfollow a user
router.put('/:username/follow', async (req, res) => {
  try {
    const currentUser = await User.findById(req.body.userId);
    const userToFollow = await User.findOne({ username: req.params.username });

    if (!userToFollow) return res.status(404).json({ message: 'User not found' });

    // Follow or unfollow logic
    if (!currentUser.following.includes(userToFollow._id)) {
      currentUser.following.push(userToFollow._id);
      userToFollow.followers.push(currentUser._id);
    } else {
      currentUser.following.pull(userToFollow._id);
      userToFollow.followers.pull(currentUser._id);
    }

    await currentUser.save();
    await userToFollow.save();

    res.status(200).json({ message: 'Follow/Unfollow action successful' });
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
});

// Search users by username
router.get('/search/:username', async (req, res) => {
  try {
    const users = await User.find({ username: new RegExp(req.params.username, 'i') }).select('username email');
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
});

module.exports = router;

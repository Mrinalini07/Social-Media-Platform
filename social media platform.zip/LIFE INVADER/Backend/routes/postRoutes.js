const express = require('express');
const Post = require('../models/Post');
const router = express.Router();

// Create a post
router.post('/', async (req, res) => {
  const { userId, content, image } = req.body;

  // Check if all required fields are provided
  if (!userId || !content) {
    return res.status(400).json({ message: 'User ID and content are required' });
  }

  try {
    const post = new Post({
      userId,
      content,
      image, // Optional image field
    });
    await post.save();
    res.status(201).json(post);
  } catch (error) {
    console.error('Error creating post:', error);
    res.status(500).json({ message: 'Server Error' });
  }
});

// Get all posts
router.get('/', async (req, res) => {
  try {
    const posts = await Post.find()
      .populate('userId', 'username')  // Assuming userId is a reference to the User model
      .sort({ createdAt: -1 });        // Sort posts by createdAt in descending order
    res.json(posts);
  } catch (error) {
    console.error('Error fetching posts:', error);
    res.status(500).json({ message: 'Server Error' });
  }
});

// Like or Unlike a post
router.put('/:postId/like', async (req, res) => {
  const { userId } = req.body;
  if (!userId) {
    return res.status(400).json({ message: 'User ID is required to like/unlike a post' });
  }

  try {
    const post = await Post.findById(req.params.postId);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    // Toggle like/unlike based on whether userId is already in the likes array
    if (!post.likes.includes(userId)) {
      post.likes.push(userId); // Add the user to likes
    } else {
      post.likes.pull(userId); // Remove the user from likes
    }

    await post.save();
    res.status(200).json(post);
  } catch (error) {
    console.error('Error liking/unliking post:', error);
    res.status(500).json({ message: 'Server Error' });
  }
});

module.exports = router;

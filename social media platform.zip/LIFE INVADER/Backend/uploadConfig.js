const multer = require('multer');
const path = require('path');

// Avatar Storage
const avatarStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/avatars/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

// Post Image Storage
const postImageStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/posts/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const uploadAvatar = multer({ storage: avatarStorage });
const uploadPostImage = multer({ storage: postImageStorage });

module.exports = { uploadAvatar, uploadPostImage };

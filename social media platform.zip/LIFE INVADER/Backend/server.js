const mongoose = require('mongoose');
require('dotenv').config();  // Load environment variables from .env
const express = require('express');
const http = require('http');
const path = require('path');
const connectDB = require('./db'); // Database connection logic
const userRoutes = require('./routes/userRoutes'); // User-related API routes
const postRoutes = require('./routes/postRoutes'); // Post-related API routes
const multer = require('multer');

// Initialize app and server
const app = express();
const server = http.createServer(app);

// Middleware for serving static files
app.use('/uploads', express.static(path.join(__dirname, 'uploads'))); // Serve uploaded files

// Middleware
app.use(express.json()); // Parse JSON bodies
app.use(express.static(path.join(__dirname, '../frontend'))); // Serve static files from the frontend folder

// Connect to MongoDB
const connectToDatabase = async () => {
  try {
    // Check if mongoose is already connected, otherwise connect to MongoDB
    if (mongoose.connection.readyState !== 1) {
      await mongoose.connect(process.env.MONGO_URI, { 
        useNewUrlParser: true, 
        useUnifiedTopology: true 
      });
      console.log('MongoDB connected successfully');
    } else {
      console.log('MongoDB is already connected');
    }
  } catch (err) {
    console.error('Error connecting to MongoDB:', err);
  }
};

// Connect to the database
connectToDatabase();

// API Routes
app.use('/api/users', userRoutes); // User-related API routes
app.use('/api/posts', postRoutes); // Post-related API routes

// Serve frontend pages
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html')); // Main page
});

app.get('/chat', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/chat.html')); // Chat page
});

// Post creation route (dummy endpoint to be implemented later)
app.post('/api/posts', async (req, res) => {
  try {
    // Your post creation logic here
    res.status(201).json({ message: 'Post created successfully' });
  } catch (err) {
    console.error('Error creating post:', err);
    res.status(500).json({ message: 'Server Error' });
  }
});

// Configure multer to save uploaded avatars to the 'uploads/avatars/' folder
const upload = multer({
  dest: 'uploads/avatars/', // Directory where avatars are stored
  limits: { fileSize: 5 * 1024 * 1024 }, // Set file size limit (5 MB)
  fileFilter(req, file, cb) {
    if (!file.mimetype.startsWith('image')) {
      return cb(new Error('File must be an image'));
    }
    cb(null, true);
  },
});

// Avatar upload route
app.post('/upload-avatar', upload.single('avatar'), (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded');
  }

  // Save the file path in the database or user object
  const avatarPath = `/uploads/avatars/${req.file.filename}`;

  // Example: Update user profile with avatar URL (this should be done in your database)
  // User.update({ avatar: avatarPath }, { where: { id: userId } });

  res.json({ avatar: avatarPath });
});

// Start the server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

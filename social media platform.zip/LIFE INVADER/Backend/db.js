const mongoose = require('mongoose');

const connectDB = async () => {
  if (mongoose.connection.readyState === 0) { // Ensure no active connection
    try {
      await mongoose.connect('mongodb://localhost:27017/yourDatabaseName', {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        connectTimeoutMS: 10000,
      });
      console.log('MongoDB connected successfully!');
    } catch (error) {
      console.error('Error connecting to MongoDB:', error.message);
      process.exit(1);
    }
  } else {
    console.log('Already connected to MongoDB.');
  }
};

module.exports = connectDB;

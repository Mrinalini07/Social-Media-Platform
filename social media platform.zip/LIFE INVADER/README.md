# VibeNet

VibeNet is a modern social media platform designed to connect users through posts, comments, likes, and follows. Inspired by Instagram, VibeNet features a dark-themed UI for a sleek and user-friendly experience.

---

## Features

### User Features
- **User Profile**:
  - Customizable avatar with upload functionality.
  - Display of stats (posts, followers, following).
  - Editable bio and username.
  
- **Post Interaction**:
  - Create posts with text and image uploads.
  - Like and comment on posts.
  - View feeds with posts from followed users.

- **Social Features**:
  - Follow/unfollow users.
  - Interactive like and comment buttons.

### Authentication
- Advanced **login** and **signup** pages with separate CSS styles.
- Secure user authentication and session handling.

### Dark Theme
- Consistent dark-themed UI across all pages for a modern look.

---

## Installation

### Backend Setup
1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/vibenet.git

Acknowledgments
Inspired by Instagram for the design and layout.
Built using Node.js, Express.js, and MongoDB for the backend.
Frontend designed with HTML, CSS, and JavaScript.


Feel free to modify this file to suit your exact setup and project details.
